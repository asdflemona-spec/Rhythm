package com.example.rhythm;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.SeekBar;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView time, beat, count, tempo, message;
    private Button start, tap;
    private boolean running = false;
    private int bpm = 90, taps = 0, beatIndex = 0;
    private long startTime, nextBeat;
    private final long duration = 10 * 60 * 1000L;
    private ToneGenerator tone;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            long now = android.os.SystemClock.elapsedRealtime();
            long elapsed = now - startTime;
            if (elapsed >= duration) { stopSession(true); return; }
            long remain = (duration - elapsed + 999) / 1000;
            time.setText(String.format(Locale.KOREA, "%02d:%02d 남음", remain / 60, remain % 60));
            long interval = 60000L / bpm;
            if (now >= nextBeat) {
                beatIndex++;
                beat.setText(beatIndex % 2 == 0 ? "●  ○  ●  ○" : "○  ●  ○  ●");
                beat.setTextColor(beatIndex % 2 == 0 ? Color.rgb(107,220,176) : Color.rgb(255,209,125));
                if (tone != null) tone.startTone(ToneGenerator.TONE_PROP_BEEP, 55);
                nextBeat += interval;
                if (nextBeat < now) nextBeat = now + interval;
            }
            handler.postDelayed(this, 35);
        }
    };
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private TextView text(String s, int size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER); return t; }
    private void add(LinearLayout root, View v, int height, int margin) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height < 0 ? height : dp(height)); p.setMargins(0,dp(margin),0,dp(margin)); root.addView(v,p); }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(14,23,36)); getWindow().setNavigationBarColor(Color.rgb(14,23,36));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setGravity(Gravity.CENTER_HORIZONTAL); root.setPadding(dp(24),dp(22),dp(24),dp(22)); root.setBackgroundColor(Color.rgb(14,23,36));
        TextView title = text("낮 리듬 활동", 29, Color.WHITE); title.setTypeface(null,Typeface.BOLD); add(root,title,56,2);
        message = text("낮에 가볍게 움직이며 박자를 즐겨보세요.\n세로토닌 증가를 보장하는 활동은 아닙니다.",14,Color.rgb(184,199,215)); add(root,message,68,4);
        tempo = text("박자 90 BPM",21,Color.rgb(255,209,125)); add(root,tempo,40,6);
        SeekBar seek = new SeekBar(this); seek.setMax(60); seek.setProgress(30); add(root,seek,44,0);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { public void onProgressChanged(SeekBar s,int progress,boolean user) { bpm=60+progress; tempo.setText("박자 " + bpm + " BPM"); } public void onStartTrackingTouch(SeekBar s) {} public void onStopTrackingTouch(SeekBar s) {} });
        beat = text("○  ●  ○  ●",37,Color.rgb(107,220,176)); beat.setBackground(bg(Color.rgb(27,43,59),20)); add(root,beat,110,12);
        time = text("10:00 준비",25,Color.WHITE); add(root,time,44,4);
        count = text("터치 0회",18,Color.rgb(184,199,215)); add(root,count,35,0);
        tap = new Button(this); tap.setText("박자에 맞춰 터치"); tap.setTextSize(20); tap.setTextColor(Color.rgb(10,30,35)); tap.setAllCaps(false); tap.setBackground(bg(Color.rgb(107,220,176),18)); add(root,tap,84,12);
        tap.setOnClickListener(v -> { if (running) { taps++; count.setText("터치 " + taps + "회"); } });
        start = new Button(this); start.setText("10분 시작"); start.setAllCaps(false); start.setTextSize(17); start.setTextColor(Color.WHITE); start.setBackground(bg(Color.rgb(51,78,107),16)); add(root,start,60,7);
        start.setOnClickListener(v -> { if (running) stopSession(false); else startSession(); });
        TextView note = text("선택: 제자리걸음으로 박자를 따라가도 좋아요.\n휴대폰을 보며 걷지 마세요. 불편하면 멈추세요.",13,Color.rgb(150,166,185)); add(root,note,70,10);
        setContentView(root);
    }
    private void startSession() { running=true; taps=0; beatIndex=0; count.setText("터치 0회"); start.setText("중지하기"); message.setText("편한 속도로 터치하거나 제자리걸음을 해보세요."); startTime=android.os.SystemClock.elapsedRealtime(); nextBeat=startTime; try { tone=new ToneGenerator(AudioManager.STREAM_MUSIC,18); } catch(Exception ignored) {} handler.post(tick); }
    private void stopSession(boolean finished) { running=false; handler.removeCallbacks(tick); if(tone!=null) {tone.release(); tone=null;} start.setText("다시 시작"); beat.setText("○  ●  ○  ●"); time.setText(finished?"10분 완료":"일시 종료"); message.setText(finished?"수고했어요! 낮 동안 규칙적인 활동을 이어가 보세요.":"언제든 다시 시작할 수 있어요."); }
    @Override protected void onPause() { super.onPause(); if(running) stopSession(false); }
    @Override protected void onDestroy() { handler.removeCallbacks(tick); if(tone!=null) tone.release(); super.onDestroy(); }
}
