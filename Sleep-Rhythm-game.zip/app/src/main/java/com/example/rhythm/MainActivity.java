package com.example.rhythm;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends Activity {
    private SleepView view;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(5894 | 1024 | 512);
        view = new SleepView(); setContentView(view);
    }
    class SleepView extends View {
        Paint p = new Paint(3);
        int bpm = 60;
        long start = SystemClock.elapsedRealtime();
        long lastTap = 0;
        boolean finished = false;
        SleepView() { super(MainActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        void color(int c) { p.setColor(c); p.setStyle(Paint.Style.FILL); }
        void text(Canvas c, String s, float x, float y, float size, int col) {
            color(col); p.setTextSize(size); p.setTextAlign(Paint.Align.CENTER); c.drawText(s,x,y,p);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(),h=getHeight(), cx=w/2f,cy=h/2f;
            c.drawColor(Color.rgb(9,15,25));
            long now=SystemClock.elapsedRealtime(), elapsed=now-start;
            if (elapsed>=600000) finished=true;
            int white=Color.rgb(191,211,217), muted=Color.rgb(123,152,167);
            if (finished) {
                text(c,"Rest well",cx,cy, Math.min(w*.085f,46),white);
                text(c,"Session complete - tap to restart",cx,cy+55,Math.min(w*.038f,22),muted);
                return;
            }
            double period=60000.0/bpm;
            double phase=(elapsed%period)/period;
            float pulse=(float)(.5+.5*Math.cos(phase*Math.PI*2));
            float radius=Math.min(w,h)*(.20f+.025f*pulse);
            color(Color.rgb(25,48,66)); c.drawCircle(cx,cy,radius*1.35f,p);
            color(Color.rgb(55+(int)(pulse*16),110+(int)(pulse*15),126+(int)(pulse*13)));
            c.drawCircle(cx,cy,radius,p);
            color(Color.rgb(112,171,178)); c.drawCircle(cx,cy,radius*.72f,p);
            text(c,"Breathe gently",cx,h*.18f,Math.min(w*.067f,38),white);
            text(c,"Tap softly with the pulse",cx,h*.245f,Math.min(w*.037f,22),muted);
            if(now-lastTap<500) {
                color(Color.argb((int)(65*(1-(now-lastTap)/500f)),194,220,215));
                c.drawCircle(cx,cy,radius*1.65f,p);
            }
            int remaining=(int)((600000-elapsed+999)/1000);
            text(c,String.format(java.util.Locale.US,"%02d:%02d remaining",remaining/60,remaining%60),cx,h*.78f,Math.min(w*.048f,25),white);
            text(c,"-     "+bpm+" BPM     +",cx,h*.86f,Math.min(w*.055f,28),white);
            text(c,"Tap bottom to end early",cx,h*.94f,Math.min(w*.033f,18),muted);
            postInvalidateDelayed(32);
        }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_DOWN) return true;
            float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(finished){finished=false;start=SystemClock.elapsedRealtime();}
            else if(y>h*.90f){finished=true;}
            else if(y>h*.80f){bpm=Math.max(50,Math.min(80,bpm+(x>w/2?5:-5)));}
            else lastTap=SystemClock.elapsedRealtime();
            invalidate();return true;
        }
    }
}
