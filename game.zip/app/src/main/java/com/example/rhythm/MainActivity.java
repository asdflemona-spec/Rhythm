package com.example.rhythm;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b) { super.onCreate(b); setContentView(new Game()); }
  class Game extends View {
    Paint p=new Paint(3); Random random=new Random(42); ArrayList<Note> notes=new ArrayList<>();
    ToneGenerator tone=new ToneGenerator(AudioManager.STREAM_MUSIC,65);
    long start; boolean playing=false, finished=false; int score=0,combo=0,best=0,miss=0; String judge="TAP TO START"; long judgeAt=0;
    final int[] colors={0xff41d9ff,0xffff61b6,0xffae7cff,0xffffcf57};
    class Note {int lane; long time; boolean hit=false; Note(int l,long t){lane=l;time=t;}}
    Game(){super(MainActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    void reset(){notes.clear();random.setSeed(42);for(int i=0;i<110;i++)notes.add(new Note(random.nextInt(4),1600+i*350));score=combo=miss=0;playing=true;finished=false;start=android.os.SystemClock.uptimeMillis();judge="READY";judgeAt=start;invalidate();}
    void txt(String s,float x,float y,int size,int color){p.setColor(color);p.setTextSize(size);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));canvas.drawText(s,x,y,p);}
    Canvas canvas;
    @Override protected void onDraw(Canvas c){canvas=c;float w=getWidth(),h=getHeight(),laneW=w/4f,hitY=h*.82f; c.drawColor(0xff0d1024);long now=android.os.SystemClock.uptimeMillis(),t=now-start;
      p.setColor(0xff19223e);c.drawRoundRect(0,h*.12f,w,h,20,20,p);
      for(int i=0;i<4;i++){p.setColor(i%2==0?0xff202b4c:0xff17213d);c.drawRect(i*laneW+3,h*.12f,(i+1)*laneW-3,h,p);p.setColor(colors[i]);p.setAlpha(70);c.drawRoundRect(i*laneW+5,hitY,(i+1)*laneW-5,hitY+18,8,8,p);p.setAlpha(255);}
      if(playing){for(Note n:notes){if(n.hit)continue;float y=hitY-(n.time-t)*h/1700f;if(y>h*.08f&&y<h+50){p.setColor(colors[n.lane]);c.drawRoundRect(n.lane*laneW+9,y-15,(n.lane+1)*laneW-9,y+15,12,12,p);}if(t-n.time>160){n.hit=true;combo=0;miss++;judge="MISS";judgeAt=now;}}
        if(t>41000){playing=false;finished=true;}postInvalidateDelayed(16);
      }
      txt("R H Y T H M",w/2,h*.075f,Math.max(28,(int)(w/12)),0xffffffff);
      txt("SCORE  "+score,w*.27f,h*.15f,Math.max(16,(int)(w/23)),0xffffffff);txt("COMBO  "+combo,w*.75f,h*.15f,Math.max(16,(int)(w/23)),0xffffffff);
      if(now-judgeAt<600||!playing)txt(judge,w/2,h*.43f,Math.max(28,(int)(w/11)),0xffffffff);
      if(!playing){p.setColor(0xcc0d1024);c.drawRoundRect(w*.08f,h*.48f,w*.92f,h*.69f,24,24,p);txt(finished?"FINISHED":"4-LANE RHYTHM",w/2,h*.55f,Math.max(22,(int)(w/14)),0xffffffff);txt(finished?"TAP TO RESTART":"TAP TO PLAY",w/2,h*.63f,Math.max(20,(int)(w/17)),0xff41d9ff);}
    }
    @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;if(!playing){reset();return true;}int lane=Math.min(3,(int)(e.getX()/(getWidth()/4f)));long t=android.os.SystemClock.uptimeMillis()-start;Note closest=null;long delta=99999;for(Note n:notes){long d=Math.abs(n.time-t);if(!n.hit&&n.lane==lane&&d<delta){closest=n;delta=d;}}if(closest!=null&&delta<=160){closest.hit=true;combo++;best=Math.max(best,combo);if(delta<=65){score+=1000;judge="PERFECT";}else{score+=500;judge="GOOD";}tone.startTone(ToneGenerator.TONE_PROP_BEEP,60);}else{combo=0;judge="MISS";}judgeAt=android.os.SystemClock.uptimeMillis();invalidate();return true;}
  }
}
